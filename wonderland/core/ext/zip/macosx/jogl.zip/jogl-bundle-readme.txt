Extracted from : jogl-1.1.2-pre-20080523-macosx-universal.zip
On date        : Thu Sep  4 11:19:05 PDT 2008
