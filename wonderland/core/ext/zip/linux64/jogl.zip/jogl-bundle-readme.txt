Extracted from : jogl-1.1.1a-linux-amd64.zip
On date        : Mon Aug 17 11:28:00 PDT 2009
